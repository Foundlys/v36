'use strict';
const path=require('node:path');
const repo=process.argv[2],prefix=process.argv[3];if(!repo||!prefix)throw Error('Repository and output prefix are required');
const fixture=require(path.join(repo,'zero-evaluation/fixture')),original=fixture.fixture;
fixture.fixture=options=>original({...options,NODE_OPTIONS:'--require='+path.join(__dirname,'seed-io-metrics.cjs'),FOUNDLY_EVALUATION_IO_METRICS:prefix+'-io.json'});
require(path.join(repo,'zero-evaluation/social-collect')).collect({industry:'ECOMMERCE',output:prefix+'-collection.json'}).then(report=>console.log(JSON.stringify({source:report.source,seed:report.seed,cases:report.cases.length,quality_status:report.quality_status}))).catch(error=>{console.error(error.stack);process.exitCode=1;});
