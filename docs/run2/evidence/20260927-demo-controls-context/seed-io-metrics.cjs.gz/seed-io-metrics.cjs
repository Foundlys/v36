'use strict';
// Isolated benchmark instrumentation. No file content, keys or credentials are
// retained. Native atomic write, fsync, rename and encryption remain unchanged.
const fs=require('node:fs'),path=require('node:path');
const target=path.join(process.env.FOUNDLY_DATA_DIR,'foundly-core-state.json'),output=process.env.FOUNDLY_EVALUATION_IO_METRICS;
const originals=Object.fromEntries(['openSync','writeFileSync','fsyncSync','closeSync','renameSync'].map(name=>[name,fs[name]]));
const opened=new Set(),started=process.hrtime.bigint();
const metrics={atomic_writes:0,bytes_written:0,write_calls:0,fsync_calls:0,write_ms:0,fsync_ms:0,last_snapshot_bytes:0};
fs.openSync=function(file,...args){const fd=originals.openSync.call(fs,file,...args);if(typeof file==='string'&&file.startsWith(target+'.tmp-'))opened.add(fd);return fd;};
fs.writeFileSync=function(file,data,...args){if(!opened.has(file))return originals.writeFileSync.call(fs,file,data,...args);const before=process.hrtime.bigint();try{return originals.writeFileSync.call(fs,file,data,...args);}finally{metrics.write_calls++;metrics.bytes_written+=Buffer.byteLength(data);metrics.last_snapshot_bytes=Buffer.byteLength(data);metrics.write_ms+=Number(process.hrtime.bigint()-before)/1e6;}};
fs.fsyncSync=function(fd,...args){if(!opened.has(fd))return originals.fsyncSync.call(fs,fd,...args);const before=process.hrtime.bigint();try{return originals.fsyncSync.call(fs,fd,...args);}finally{metrics.fsync_calls++;metrics.fsync_ms+=Number(process.hrtime.bigint()-before)/1e6;}};
fs.closeSync=function(fd,...args){try{return originals.closeSync.call(fs,fd,...args);}finally{opened.delete(fd);}};
fs.renameSync=function(from,to,...args){const r=originals.renameSync.call(fs,from,to,...args);if(to===target)metrics.atomic_writes++;return r;};
process.on('exit',()=>{if(output)originals.writeFileSync(output,JSON.stringify({...metrics,elapsed_ms:Number(process.hrtime.bigint()-started)/1e6,cpu_usage:process.cpuUsage(),resource_usage:process.resourceUsage(),node_version:process.version},null,2)+'\n');});
